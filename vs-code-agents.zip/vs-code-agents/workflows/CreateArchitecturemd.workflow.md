# Workflow: App Interaction & Architecture Documentation

This workflow enables a stack-agnostic, automated process for reverse-engineering any repository to generate comprehensive architecture diagrams and user-interaction documentation. It leverages specialized agents to move from raw discovery to visual synthesis.

## Prerequisites
- **Analyst Agent** configured with `analysis-methodology` skill.
- **Architect Agent** configured with `architecture-patterns` skill.
- **QA Agent** for behavioral flow validation.
- **Flowbaby Extension** (optional but recommended for cross-session memory).
- **Unified Numbering**: Ensure `agent-output/.next-id` is initialized.

---

## Phase 1: Deep Discovery (The Analyst)
**Objective**: Identify the "mental model" of the codebase and establish technical entry points.

1. **Invoke Analyst**: Provide the following prompt to the Analyst agent.
2. **Drafting Discovery**:
   > "I need a deep discovery pass on this repo. Please identify:
   > 1. **Entry Points**: Where does the app start? (e.g., `main.ts`, `App.xaml`, `index.js`, `Program.cs`).
   > 2. **Core Layers**: How is the code organized? (e.g., Controllers, Services, ViewModels).
   > 3. **Data Sources**: Where does data come from? (Internal DBs, External APIs, State Management).
   > 4. **Infrastructure**: Detect the stack and build tools.
   > 
   > Create an analysis report in `agent-output/analysis/NNN-system-discovery.md` using the `analysis-methodology` skill."

---

## Phase 2: Interaction Mapping (The Analyst + QA)
**Objective**: Map the behavioral "WHAT" of the application through primary user-facing flows.

1. **Invoke Analyst (subagent context)**: Use this prompt to trace logic.
2. **Tracing Flows**:
   > "Based on the discovery in `NNN-system-discovery.md`, trace the primary user-facing flows:
   > 1. **Initialization Flow**: What happens when the app first opens?
   > 2. **Core Feature Flow**: Trace the path from a specific user action to a data change.
   > 3. **Error Handling**: How are failures surfaced to the UI?
   > 
   > Output these findings as step-by-step logic flows in the analysis document."

---

## Phase 3: Architectural Synthesis (The Architect)
**Objective**: Transform findings into technical visuals using Mermaid.js syntax.

1. **Invoke Architect**: Provide the Analyst's findings for visual documentation.
2. **Generating Diagrams**:
   > "Using the analysis in `agent-output/analysis/`, generate a comprehensive `system-architecture.md`. Use the `architecture-patterns` skill to create:
   > 1. **C4 Context Diagram**: High-level interactions with external systems.
   > 2. **Component Diagram**: Showing internal layering (e.g., UI → Business Logic → Data).
   > 3. **Sequence Diagram**: Visualizing the core feature flow identified by the Analyst.
   > 
   > Ensure all diagrams use Mermaid syntax for version control compatibility."

---

## Phase 4: Assembly (The Master README)
Combine the generated artifacts into a single `README-ARCH.md` at the root of the repository.

### Master README Template

```markdown
# App Architecture & Interactions

## 🚀 System Overview
[Summary of the app's purpose discovered in Phase 1]

## 🏗️ Technical Stack
- **Frontend/UI**: [Detected Framework]
- **Logic/Backend**: [Detected Language/Runtime]
- **State/Data**: [Detected Storage/Management]

## 🗺️ System Architecture
### High-Level Component Map
\```mermaid
[Insert Architect's Component Diagram here]
\```

## 🔄 Core App Flows
### User Interaction: [Feature Name]
\```mermaid
[Insert Architect's Sequence Diagram here]
\```

## 📂 Project Structure
[Standardized directory tree with descriptions of each layer]

## 🛡️ Boundary & Trust Rules
- **Data Flow**: Data moves from [Source] to [Sink] via [Protocol].
- **Validation**: Input is validated at [Layer Name].